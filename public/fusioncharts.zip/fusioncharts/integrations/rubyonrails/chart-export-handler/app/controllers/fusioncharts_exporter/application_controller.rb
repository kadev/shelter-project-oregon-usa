module FusionchartsExporter
  class ApplicationController < ActionController::Base
  end
end
